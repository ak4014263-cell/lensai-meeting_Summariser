globalThis.__BUILD_MANIFEST = {
  "pages": {
    "/_app": []
  },
  "devFiles": [],
  "polyfillFiles": [
    "static/chunks/0cz1d0mv5g_q7.js"
  ],
  "lowPriorityFiles": [
    "static/b-6ZKPbqsdm9L0RTQ1SDv/_buildManifest.js",
    "static/b-6ZKPbqsdm9L0RTQ1SDv/_ssgManifest.js",
    "static/b-6ZKPbqsdm9L0RTQ1SDv/_clientMiddlewareManifest.js"
  ],
  "rootMainFiles": [
    "static/chunks/3yfl9fgvivx3-.js",
    "static/chunks/11jq0c2_zavac.js",
    "static/chunks/3kmozkq6tgqnz.js",
    "static/chunks/3jg84jwj6s1uj.js",
    "static/chunks/turbopack-3a36h81pbc9lk.js"
  ],
  "rootMainFilesTree": {},
  "pagesChunkGroupBootstrapParams": {},
  "chunkLoadingGlobal": "TURBOPACK"
};
